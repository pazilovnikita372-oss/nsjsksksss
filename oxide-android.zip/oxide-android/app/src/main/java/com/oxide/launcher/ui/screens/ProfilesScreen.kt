package com.oxide.launcher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.data.OxideProfile
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.OxideViewModel

private val themeColors = mapOf(
    "blue"   to OxideNeonBlue,
    "purple" to OxideNeonPurple,
    "pink"   to OxideNeonPink,
    "cyan"   to OxideNeonCyan
)

@Composable
fun ProfilesScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<OxideProfile?>(null) }
    var editProfile  by remember { mutableStateOf<OxideProfile?>(null) }

    OxideBackground {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            OxideTopBar(title = "ПРОФИЛИ", onBack = { navController.popBackStack() })
            NeonDivider()

            // Info banner
            GlassCard(Modifier.fillMaxWidth().padding(16.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null,
                        tint = OxideNeonBlue, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Профили — локальные настройки OXIDE.\nНе изменяют параметры реального устройства.",
                        fontSize = 11.sp, color = OxideTextSecond
                    )
                }
            }

            if (uiState.profiles.isEmpty()) {
                EmptyState(Icons.Default.Person, "Нет профилей. Создайте первый!")
            } else {
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(uiState.profiles, key = { it.id }) { profile ->
                        ProfileCard(
                            profile  = profile,
                            onSelect = { viewModel.switchProfile(profile.id) },
                            onEdit   = { editProfile = profile },
                            onDelete = if (uiState.profiles.size > 1) {
                                { pendingDelete = profile }
                            } else null
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }

            // FAB
            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.BottomEnd) {
                FloatingActionButton(
                    onClick          = { showAddDialog = true },
                    containerColor   = OxideNeonBlue,
                    contentColor     = OxideDeepBlack
                ) { Icon(Icons.Default.Add, contentDescription = "Добавить профиль") }
            }
        }

        // Add dialog
        if (showAddDialog) AddProfileDialog(
            onDismiss = { showAddDialog = false },
            onAdd     = { name, theme ->
                viewModel.addProfile(name, theme)
                showAddDialog = false
            }
        )

        // Edit dialog
        editProfile?.let { p ->
            AddProfileDialog(
                onDismiss    = { editProfile = null },
                onAdd        = { name, theme ->
                    viewModel.updateProfile(p.copy(name = name, themeColor = theme))
                    editProfile = null
                },
                initialName  = p.name,
                initialTheme = p.themeColor,
                isEdit       = true
            )
        }

        // Confirm delete
        pendingDelete?.let { p ->
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title   = { Text("Удалить профиль?", color = OxideTextPrimary) },
                text    = { Text("«${p.name}» будет удалён. Это действие нельзя отменить.", color = OxideTextSecond) },
                confirmButton = {
                    TextButton(onClick = { viewModel.deleteProfile(p.id); pendingDelete = null }) {
                        Text("Удалить", color = OxideError)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDelete = null }) {
                        Text("Отмена", color = OxideTextSecond)
                    }
                },
                containerColor = OxideNavyBlue
            )
        }

        // Snack
        uiState.snackMessage?.let { msg ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action   = { TextButton(onClick = { viewModel.clearSnack() }) { Text("OK") } }
            ) { Text(msg) }
        }
    }
}

@Composable
private fun ProfileCard(
    profile: OxideProfile,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onDelete: (() -> Unit)?
) {
    val accent = themeColors[profile.themeColor] ?: OxideNeonBlue
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (profile.isCurrent) accent else OxideGlassBorder,
        onClick = onSelect
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar circle
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(accent.copy(0.2f), CircleShape)
                    .border(1.5.dp, accent.copy(0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    profile.name.take(1).uppercase(),
                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = accent
                )
            }

            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(profile.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        color = OxideTextPrimary)
                    if (profile.isCurrent) {
                        Spacer(Modifier.width(8.dp))
                        OxideBadge("ACTIVE", OxideNeonCyan)
                    }
                }
                Text("Тема: ${profile.themeColor}", fontSize = 11.sp, color = OxideTextSecond)
            }

            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Изменить",
                    tint = OxideNeonBlue, modifier = Modifier.size(20.dp))
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить",
                        tint = OxideError.copy(0.7f), modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun AddProfileDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String) -> Unit,
    initialName: String = "",
    initialTheme: String = "blue",
    isEdit: Boolean = false
) {
    var name by remember { mutableStateOf(initialName) }
    var selectedTheme by remember { mutableStateOf(initialTheme) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = OxideNavyBlue,
        title = { Text(if (isEdit) "Редактировать профиль" else "Новый профиль",
            color = OxideTextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Имя профиля", color = OxideTextSecond) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = OxideNeonBlue,
                        unfocusedBorderColor = OxideGlassBorder,
                        focusedTextColor     = OxideTextPrimary,
                        unfocusedTextColor   = OxideTextPrimary
                    ),
                    singleLine = true
                )
                Text("Цвет темы:", fontSize = 12.sp, color = OxideTextSecond)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    themeColors.forEach { (key, color) ->
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (selectedTheme == key) 2.dp else 0.dp,
                                    color = Color.White,
                                    shape = CircleShape
                                )
                                .clickable { selectedTheme = key }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (name.isNotBlank()) onAdd(name.trim(), selectedTheme) }
            ) { Text(if (isEdit) "Сохранить" else "Создать", color = OxideNeonBlue) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена", color = OxideTextSecond) }
        }
    )
}
