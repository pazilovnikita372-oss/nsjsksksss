package com.oxide.launcher.ui.theme

import androidx.compose.ui.graphics.Color

// OXIDE neon palette
val OxideDeepBlack    = Color(0xFF050810)
val OxideSpaceBlue    = Color(0xFF0A0E1F)
val OxideNavyBlue     = Color(0xFF0D1433)
val OxideNeonBlue     = Color(0xFF00B4FF)
val OxideNeonCyan     = Color(0xFF00FFFF)
val OxideNeonPurple   = Color(0xFF7B2FFF)
val OxideNeonViolet   = Color(0xFFAA00FF)
val OxideNeonPink     = Color(0xFFFF00CC)
val OxideGlassWhite   = Color(0x1AFFFFFF)
val OxideGlassBorder  = Color(0x33FFFFFF)
val OxideGlassBorderB = Color(0x4400B4FF)
val OxideTextPrimary  = Color(0xFFEEF3FF)
val OxideTextSecond   = Color(0xFF8899CC)
val OxideError        = Color(0xFFFF4466)
val OxideSuccess      = Color(0xFF00FF88)
val OxideWarning      = Color(0xFFFFAA00)

// Gradient stops
val GradientStart     = Color(0xFF0D1433)
val GradientMid       = Color(0xFF1A0A2E)
val GradientEnd       = Color(0xFF050810)
