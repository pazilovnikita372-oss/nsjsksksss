package com.oxide.launcher.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.oxide.launcher.ui.screens.*
import com.oxide.launcher.viewmodel.OxideViewModel

sealed class Screen(val route: String) {
    object Home     : Screen("home")
    object Files    : Screen("files")
    object Apps     : Screen("apps")
    object Settings : Screen("settings")
    object Profiles : Screen("profiles")
    object Skins    : Screen("skins")
    object About    : Screen("about")
}

@Composable
fun OxideNavGraph(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController = navController, viewModel = viewModel)
        }
        composable(Screen.Files.route) {
            FilesScreen(navController = navController, viewModel = viewModel)
        }
        composable(Screen.Apps.route) {
            AppsScreen(navController = navController, viewModel = viewModel)
        }
        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController, viewModel = viewModel)
        }
        composable(Screen.Profiles.route) {
            ProfilesScreen(navController = navController, viewModel = viewModel)
        }
        composable(Screen.Skins.route) {
            SkinsScreen(navController = navController, viewModel = viewModel)
        }
        composable(Screen.About.route) {
            AboutScreen(navController = navController)
        }
    }
}
